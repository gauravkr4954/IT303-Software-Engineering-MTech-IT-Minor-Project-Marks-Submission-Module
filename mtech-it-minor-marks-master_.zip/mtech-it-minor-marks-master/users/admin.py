from django.contrib import admin
from .models import Profile,Student,Faculty
# Register your models here.

admin.site.register(Profile)
admin.site.register(Student)
admin.site.register(Faculty)
